import openai
from flask import Flask, request, jsonify
import datetime

# INIT
app = Flask(__name__)
openai.api_key = "your-openai-key-here"  # Replace securely in production

@app.route('/nova', methods=['POST'])
def nova_prompt():
    data = request.json
    user_input = data.get("prompt", "")
    print(f"[Nova] Prompt received: {user_input}")

    # Call OpenAI API
    try:
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": "You are Nova, a highly advanced AI in the VoltAir-AiSpark platform."},
                {"role": "user", "content": user_input}
            ]
        )
        result = response.choices[0].message['content']
        return jsonify({"response": result})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/')
def home():
    return "<h1>Nova is live on VoltAir-AiSpark Replit Core</h1>"

# Run the assistant server
if __name__ == '__main__':
    print(f"[Nova] Activated at {datetime.datetime.now()}")
    app.run(host="0.0.0.0", port=3000)
